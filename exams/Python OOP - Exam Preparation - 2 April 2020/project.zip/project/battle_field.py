from project.player.player import Player


class BattleField:

    @staticmethod
    def fight(attacker: Player, enemy: Player):
        pass
