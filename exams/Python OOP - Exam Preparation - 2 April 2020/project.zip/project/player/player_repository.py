from project.player.player import Player


class PlayerRepository:
    # count: int
    # players: List[Player]

    def __init__(self):
        self.count = 0
        self.players = []

    def add(self, player: Player):
        pass

    def remove(self, player: str):
        pass

    def find(self, username: str):
        pass